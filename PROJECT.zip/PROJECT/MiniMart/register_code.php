<?php
include_once("db.php");
?>

<?php

if(isset($_POST['reg']))	
	{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$ph_no=$_POST['phone'];		
		$pwd=$_POST['password'];
		$repassword=$_POST['Re_Password'];
		
			if($pwd==$repassword)
				{
					$data=mysql_query("insert into `user`(`name`, `email`, `ph_no`, `pwd`) values ('$name','$email', '$ph_no', '$pwd')");
					
						if($data==1)
							{
								echo"<script>alert('Account Created'); location.href='login.php';</script>";
							}
						else{ 
							echo"<script>alert('Already Registered.'); location.href='login.php';</script>";
						}
				}
			else{
				echo"<script>alert('Password miss matched'); location.href='login.php';</script>";
			}
					
		}
				
?>