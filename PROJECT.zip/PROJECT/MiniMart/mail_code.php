<?php
include_once("db.php");
?>

<?php

if(isset($_POST['contact']))
	
	{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$ph=$_POST['ph'];
		$sub=$_POST['sub'];
		$msg=$_POST['msg'];
		$dt=date('Y-m-d');
		
					$data=mysql_query("insert into `contact_us`(`name`, `email`, `ph`, `sub`, `msg`, `dt`) values ('$name','$email', '$ph', '$sub', '$msg', '$dt')");
					
						if($data==1)
							{
								echo"<script>alert('Massege has been sent successfully'); location.href='mail.php';</script>";
							}
						else{
								echo "Error occured!!! Try Again".$data.error();
							}

		}
				
?>