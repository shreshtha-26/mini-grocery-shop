<?php include_once("db.php"); ?>
<?php
	if (isset($_POST['cod'])) {
		$order_id=$_POST["order_id"];
		$sql=mysql_query("update `order` set `pay`='cash on delivery', `status`=1 where `order_id`='$order_id' ");
		if ($sql) {
			session_start();
			$_SESSION['con']=1;
		}
	}

	if (isset($_POST['card'])) {
		$order_id=$_POST["order_id"];
		$sql=mysql_query("update `order` set `pay`='paid by debit/credit card', `status`=1 where `order_id`='$order_id' ");
		if ($sql) {
			session_start();
			$_SESSION['con']=1;
		}
	}

	if (isset($_POST['net'])) {
		$order_id=$_POST["order_id"];
		$sql=mysql_query("update `order` set `pay`='paid by net banking', `status`=1 where `order_id`='$order_id' ");
		if ($sql) {
			session_start();
			$_SESSION['con']=1;
		}
	}

	foreach ($_SESSION['order'] as $key) {

		$name=$key[0];
		$quan=$key[1];
		$dis=$key[2];
		$amt=($key[3]*$quan);
		$price=$key[4];

		mysql_query("INSERT INTO `order_item` (`order_id`, `name`, `quan`, `dis`, `amt`, `price`) VALUES('$order_id', '$name', '$quan', '$dis', '$amt', '$price')");	

	}

	header("location:order_confirmed.php");

?>