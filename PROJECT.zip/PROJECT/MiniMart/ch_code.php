<?php include_once("db.php"); ?>
<?php
	if (isset($_POST['deli'])) {
		$name=$_POST['name'];
		$phone=$_POST['phone'];
		$addr=$_POST['addr'];
		$landmark=$_POST['landmark'];
		$city=$_POST['city'];
		$pin=$_POST['pin'];
		$dt=date('Y-m-d');

		$order_id=rand();

		$sql="insert into `order` (`order_id`, `name`, `phone`, `addr`, `landmark`, `city`, `pin`, `dt`) values('$order_id', '$name', '$phone', '$addr', '$landmark', '$city', '$pin', '$dt')";

		if(mysql_query($sql)) {
			$_SESSION['check']=1;
			header("location:payment.php?order_id=$order_id");
		} else {
			echo "<script>alter('Try after some time.');</script>";
		}
	}
?>