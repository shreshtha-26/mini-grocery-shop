<?php
include_once("db.php");
?>

<?php
if(isset($_POST['login']))
	
	{
		$log_id=$_POST['log_id'];
		$password=$_POST['password'];
		
			$data=mysql_query("select * from `user` where (`email`='$log_id' and `pwd`='$password') or (`ph_no`='$log_id' and `pwd`='$password')");
				
				if(mysql_num_rows($data))
					{
						$row=mysql_fetch_array($data);
						$_SESSION['uinfo']=$row;
						header('location: index.php');
						exit;
					}
				else{
						echo"<script>alert('Login Error.'); location.href='login.php';</script>";
						exit;
					
					}
	}
?>
