<?php include_once("db.php"); ?>

<?php
								$id=$_GET['id'];
								echo $id;
						?>