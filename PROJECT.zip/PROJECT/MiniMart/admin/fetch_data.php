<?php include_once("db.php"); ?>
<?php
if(isset($_POST['get_option']))
{
 $table = $_POST['get_option'];
 $find=mysql_query("select * from $table");
 while($row=mysql_fetch_array($find))
 {
  echo "<option value=".$row['sl'].">".$row['name']."</option>";
 }
 exit;
}
?>