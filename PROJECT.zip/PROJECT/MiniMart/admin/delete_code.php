<?php include_once('db.php'); ?>

<?php
	$table=$_POST['pro_type'];
	$pro_sl=$_POST['pro_name'];

	$sql=mysql_query("DELETE FROM $table WHERE `sl`='$pro_sl'");
	if ($sql) {
		echo "<script>alert('Record Deleted Successfully!!!'); location.href='delete.php';</script>";
		exit;
	} else{
		echo "<script>alert('Error occured'); location.href='delete.php';</script>";
		exit;
	}
?>