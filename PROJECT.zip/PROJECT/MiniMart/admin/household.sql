-- phpMyAdmin SQL Dump
-- version 2.10.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Apr 16, 2022 at 05:22 AM
-- Server version: 5.0.37
-- PHP Version: 5.2.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `minimart`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `household`
-- 

CREATE TABLE `household` (
  `sl` int(11) NOT NULL auto_increment,
  `name` varchar(30) NOT NULL,
  `mrp` varchar(10) NOT NULL,
  `price` varchar(10) NOT NULL,
  `weight` varchar(10) NOT NULL,
  `des` blob NOT NULL,
  `img` blob NOT NULL,
  PRIMARY KEY  (`sl`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `household`
-- 

