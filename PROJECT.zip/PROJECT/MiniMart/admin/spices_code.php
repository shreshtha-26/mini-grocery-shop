<?php include("db.php"); ?>
<?php
	$name=$_POST['name'];
	$mrp=$_POST['mrp'];
	$price=$_POST['price'];
	$weight=$_POST['weight'];
	$des=$_POST['des'];
	$img=$_FILES['img']['name'];

	$img_new=rand().'_'.$img;

	$imgurl="images/spices/".$img_new;
	$img_fetch="admin/".$imgurl;

	if($_FILES['img']['type']=="image/jpg" || $_FILES['img']['type']=="image/jpeg" || $_FILES['img']['type']=="image/gif" || $_FILES['img']['type']=="image/png")
		{
			move_uploaded_file($_FILES['img']['tmp_name'],$imgurl);
		
			$sql="INSERT INTO `spices`(`name`,`mrp`,`price`,`weight`,`des`,`img`) VALUES
		('$name','$mrp','$price','$weight','$des','$img_fetch')";
		
			mysql_query($sql);
		
			echo "<script>alert('Data Inserted Successfully....');location.href='spices.php'; </script>";
			exit;
		}
		else
		{
			echo "<script>alert('Please Select image Format File'); location.href='spices.php'; </script>";
			exit;
		}

?>